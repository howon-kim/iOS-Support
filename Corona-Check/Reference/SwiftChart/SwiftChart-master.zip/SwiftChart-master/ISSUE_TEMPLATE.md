Hi fellow developer!

Before sending an issue, please consider Stack Overflow.
Tag your question with `swiftcharts`: http://stackoverflow.com/tags/swiftcharts/info.

Also, check https://github.com/gpbl/SwiftChart#common-issues-and-solutions

Thanks!
